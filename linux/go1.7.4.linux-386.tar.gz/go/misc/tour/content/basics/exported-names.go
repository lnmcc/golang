// +build no-build OMIT

package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println(math.pi)
}
